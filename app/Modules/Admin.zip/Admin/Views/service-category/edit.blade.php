@extends('Admin::layouts.default')
 	@section('content')
		{!! Form::model($service_category, ['url' => url('admin/service/category/save', ['id' => $id]),'class'=>'form-horizontal']) !!}

                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>
                                    	@if($id) Create @else Edit @endif Service Category
                                    </strong></h3>
                                </div>
                                <div class="panel-body">
                                	<div class="form-group">
                                        <label class="col-md-3 col-xs-12 control-label">Category Name</label>
                                        <div class="col-md-6 col-xs-12">
                                            <div class="input-group">
                                                <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                        		{!! Form::text('category_name', null, [
                                        			'class' => 'form-control',
                                        			'placeholder' => 'Enter Category Name',
                                        			'id'=>'category_name'
                                        		]) !!}
                                            </div>
                                       	 	@include('Admin::common.form-error', ['field' => 'category_name'])
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 col-xs-12 control-label">Description</label>
                                        <div class="col-md-6 col-xs-12">
                                            <div class="input-group">
                                                <span class="input-group-addon"><span class="fa fa-"></span></span>
                                        		{!! Form::textarea('description', null, [
                                        			'class' => 'form-control',
                                        			'placeholder' => 'Enter Description'
                                        		]) !!}
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="col-md-3 col-xs-12 control-label">Status</label>
                                        <div class="col-md-6 col-xs-12">
                                            <div class="input-group">
                                                <span class="input-group-addon"><span class="fa fa-"></span></span>
                                        	 {!! Form::select('settings[status]', [
                                                '1' => 'Enable',
                                                '2' => 'Disable',
                                              ], array(0=>Setting::option('status')), ['class' => 'form-control select', 'placeholder' => 'Select Status']) !!}
                
                                            </div>
                                        </div>
                                    </div>
                                    
                                     <div class="form-group">
                                        <label class="col-md-3 col-xs-12 control-label">Menu</label>
                                        <div class="col-md-6 col-xs-12">
                                            <div class="input-group">
                                                <span class="input-group-addon"><span class="fa fa-"></span></span>
                                        	 {!! Form::select('settings[menu]', [
                                                '1' => 'Enable',
                                                '2' => 'Disable',
                                              ], array(0=>Setting::option('menu')), ['class' => 'form-control select', 'placeholder' => 'Select Menu']) !!}
                
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                <div class="panel-footer">
                                    <a href="{{ url('admin/service/category') }}"class="btn btn-default">Cancel</a>                                    
                                    <button type="submit" class="btn btn-primary pull-right">Submit</button>
                                </div>
		{!! Form::close() !!}
 	@endsection()