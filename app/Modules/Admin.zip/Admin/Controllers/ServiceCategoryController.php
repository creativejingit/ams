<?php

namespace App\Modules\Admin\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use  App\Modules\Admin\Models\ServiceCategory;

class ServiceCategoryController extends Controller {

    public function index()
    {
        $data['menu_active'] = 'service_category';

        $data['grid'] = [
            "columns"=>[
                "id"=> ["label"=> "ID"],
                "category_name"=> ["label"=> "Category"],
            ],
            "urls"=>[
                "editUrl" => [
                    'url'=>'admin/service/category/edit',
                    'icon'=>'fa fa-pencil'
                ],
                "deleteUrl" => [
                    'url'=>'admin/service/category/remove',
                    'icon'=>'fa fa-trash-o'
                ]
            ]
        ];
        $data['categories'] = ServiceCategory::where([]);
        return view('Admin::service-category.categories',$data);
    }
	public function add()
	{
		return $this->edit(null);
	}

	public function edit($id = null)
	{
		$service_category = ServiceCategory::findOrNew($id);
		$data['service_category'] = $service_category;
		$data['id'] = $id;
		$data['menu_active'] = 'services';
		return view('Admin::service-category.edit',$data);
	}

	public function save(Request $request, $id = null)
	{
		$rules = [
	            "category_name"  => "required"
				];

		$validator = \Validator::make($request->all(), $rules);

		if($validator->fails()) {
			return redirect()->back()->withInput()->withErrors($validator);
		}

		$data = $request->all();
		
		print_r($data);
		
		
		$service_category = ServiceCategory::findOrNew($id);
		$service_category->fill($data);
		
		$service_category->save();
		$action = ($id) ? 'updated.' : 'created.';
		return redirect('admin/service/category')->with('success',$service_category->category_name.'Category has been '.$action);
	}

	public function remove($id)
	{
		if($id) {
			ServiceCategory::find($id)->delete();
			return response()->json([
				'status'=>true
			]);		
		}
		return response()->json([
			'status'=>false
		]);		
	}
}