<?php

namespace app\Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;

class ServiceCategory extends Model
{
    protected $table    = 'service_categories';
    
    protected $fillable = [
        'category_name', 
        'description',
        'status',
        'menu',
        'parent'
    ];

}
