<?php

/**
 *	Admin Helper  
 */